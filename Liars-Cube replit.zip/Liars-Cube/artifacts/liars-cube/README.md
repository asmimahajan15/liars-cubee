# Liar's Cube: The Deception Protocol

A browser-playable 3D logic puzzle set inside a corrupted vault. Rotate a
27-cell cube, compare its clues with verified mine and safe markers, and find
the one false signal.

## The puzzle twist

Each clue counts mines in face-sharing neighboring cells, but one displayed
number is off by one; the trusted markers make exactly one clue impossible
under the visible constraints.

## Controls

- Drag or touch-drag the cube to rotate it.
- Select a numbered cell to inspect its coordinates and possible mine-count
  range.
- Use **Verify clue** to submit a deduction.
- Use a limited scan to reveal one hidden neighboring cell's safe/mine status.
- Use the optional hints to receive progressive deduction guidance.
- Reset a level, mute sound, or restart the campaign from the game controls.

## Level progression

The campaign has three fixed, handcrafted puzzles: Initiation, Contradiction,
and The Final Deception. Each puzzle is validated at startup to confirm its
mine layout, off-by-one clue, and unique contradiction. Completing a level
unlocks the next one. Each case starts at 100 points and subtracts 12 per miss,
5 per scan, and 8 per hint. After 90 seconds, it also subtracts 1 point per 30
seconds, capped at 10. Rank S requires no misses, scans, or hints and a finish
within 90 seconds; A is 75 or more points; B is below 75. Campaign rank S
requires three S cases, A requires 225 points out of 300, and B is below 225.
Campaign progress and best case scores are saved in the browser.

The visible evidence is intentionally partial: numbered cells are known safe,
marked cells are verified mine/safe statuses, and unmarked cells remain
unknown. A clue's possible range is the number of confirmed neighboring mines
through that count plus the number of unverified neighbors.

## Run

Use the Replit **Run** button to start the web app and open its preview. To run
the artifact directly in a configured workspace:

```sh
pnpm --filter @workspace/liars-cube run dev
```

The app is client-side only and uses procedural Three.js geometry and Web Audio;
it needs no login, backend, paid assets, or external API.

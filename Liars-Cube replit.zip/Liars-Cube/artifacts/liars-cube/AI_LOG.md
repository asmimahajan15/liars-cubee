# AI Development Log

## Prompts used

- **User build brief:** The user supplied the complete 340-line prompt in
  `.local/conversation-workspace/files/attached_assets/Pasted-You-are-an-expert-indie-game-developer-Three-js-enginee_1792753063925.txt`.
  Its opening instruction was: “You are an expert indie game developer,
  Three.js engineer, puzzle designer and UI/UX designer. Build a COMPLETE,
  POLISHED, BROWSER-PLAYABLE 3D puzzle game called: LIAR'S CUBE: THE DECEPTION
  PROTOCOL.” It requested working gameplay, three fixed puzzles, a usable 3D
  cube, campaign progression, scoring, audio, README.md, and this log. The brief
  ends: “Start building immediately. Do not respond with another plan. Implement
  the playable game now.”
- **Replit DESIGN subagent task:** implement the initial React interface,
  visual styling, and Three.js scene from the supplied brief; the main agent
  would own puzzle data and validation. This is a task summary, not a verbatim
  transcript. The complete verbatim user brief is preserved at the path above.

## AI tools actually used

- **Replit Agent:** integrated the artifact, implemented and validated the
  handcrafted puzzle model, refined gameplay and scoring, and documented the
  project.
- **Replit DESIGN subagent:** implemented the initial React interface, styles,
  and Three.js cube scene.
- No external AI APIs, image-generation tools, or external assets were used.

## Decisions made with AI assistance

- Each puzzle keeps its full mine layout internal while showing only a partial
  set of trusted safe/mine statuses. The displayed clue is possible only if it
  falls between the confirmed-mine count and that count plus the unknown
  neighboring cells.
- Each fixed level is validated at startup. It must have exactly one
  off-by-one clue outside its evidence range; all neighboring statuses for that
  clue must already be verified.
- A scan reveals one neighboring cell's true status, not a clue's truth value.
  The inconsistent clue's neighbors are already verified, so scanning it
  cannot expose the answer directly.
- The game is client-side only. Progress and best scores use browser storage;
  procedural Three.js geometry and Web Audio avoid external services and asset
  dependencies.

## Mistake caught and corrected

During a playability audit, I found that starting or replaying a level
automatically selected the first clue in the data. That clue was not the
answer, so the player could be nudged into an uninformed verification and lose
points. I traced it to the initial selection logic and changed both level
start and replay to begin with no clue selected.

The same requirements audit corrected the first UI pass's 1,000-point case
score and level-reset confirmation: the brief calls for scores out of 100 and
confirmation only for a full campaign restart.

## Verification

- Puzzle assertions confirmed 27 cells per level, one unique impossible clue,
  a valid correct-answer check, and scans that reveal an adjacent true status
  without directly scanning the inconsistent clue.
- The game TypeScript check passed. The production Vite build passed when run
  with the artifact's required `PORT` and `BASE_PATH` environment variables.
- Desktop and mobile home screens were previewed without browser-console
  errors. The game scene was typechecked and its puzzle logic was assertion
  tested, but no scripted browser end-to-end interaction test was run. The Vite
  build reports a large JavaScript chunk warning because the game includes
  Three.js.

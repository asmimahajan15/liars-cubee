export type LevelId = 1 | 2 | 3;
export type CellStatus = "mine" | "safe";
export type CellView = {
  id: string;
  x: number;
  y: number;
  z: number;
  kind: "clue" | "mine" | "safe" | "unknown";
  clue?: number;
};

export type LevelInfo = {
  id: LevelId;
  name: string;
  theme: string;
  tagline: string;
  scanLimit: number;
  hints: readonly string[];
};

export const LEVELS: readonly LevelInfo[] = [
  {
    id: 1,
    name: "INITIATION",
    theme: "THE FIRST BREACH",
    tagline: "The vault is quiet. The first signal is not.",
    scanLimit: 4,
    hints: [
      "Start with the core clue. Every one of its face-sharing neighbors has a verified status.",
      "Count the marked mines around the core, then compare that total to its displayed number.",
    ],
  },
  {
    id: 2,
    name: "CONTRADICTION",
    theme: "THE BROKEN SIGNAL",
    tagline: "One signal has been shifted by exactly one.",
    scanLimit: 3,
    hints: [
      "A boundary cell has fewer face-sharing neighbors than a cell in the core.",
      "Look for a clue whose confirmed mine count already exceeds what its number allows.",
    ],
  },
  {
    id: 3,
    name: "THE FINAL DECEPTION",
    theme: "THE VAULT CORE",
    tagline: "One last signal is outside the limits of possibility.",
    scanLimit: 2,
    hints: [
      "The vault core has six face-sharing neighbors. Their verified marks are enough to settle one clue.",
      "Ignore the unknown cells for that clue: every one of its neighbors has already been checked.",
    ],
  },
];

type Puzzle = {
  info: LevelInfo;
  mineIds: readonly string[];
  confirmedMineIds: readonly string[];
  confirmedSafeIds: readonly string[];
  clueIds: readonly string[];
  liarId: string;
  liarOffset: -1 | 1;
};

const id = (x: number, y: number, z: number) => `${x}-${y}-${z}`;
const ids = (positions: readonly (readonly [number, number, number])[]) =>
  positions.map(([x, y, z]) => id(x, y, z));

const PUZZLES: Record<LevelId, Puzzle> = {
  1: {
    info: LEVELS[0],
    mineIds: ids([
      [0, 1, 1],
      [1, 1, 0],
      [0, 0, 0],
      [2, 2, 2],
      [0, 2, 0],
      [2, 0, 2],
      [0, 2, 2],
      [2, 0, 0],
      [2, 2, 0],
    ]),
    confirmedMineIds: ids([
      [0, 1, 1],
      [1, 1, 0],
    ]),
    confirmedSafeIds: ids([
      [2, 1, 1],
      [1, 0, 1],
      [1, 2, 1],
      [1, 1, 2],
    ]),
    clueIds: ids([
      [1, 1, 1],
      [2, 1, 1],
      [1, 0, 1],
      [1, 2, 1],
      [1, 1, 2],
      [0, 0, 1],
      [2, 2, 1],
      [1, 0, 0],
      [0, 2, 1],
      [2, 0, 1],
      [1, 2, 0],
      [2, 1, 0],
    ]),
    liarId: id(1, 1, 1),
    liarOffset: 1,
  },
  2: {
    info: LEVELS[1],
    mineIds: ids([
      [1, 1, 1],
      [2, 0, 1],
      [2, 1, 2],
      [0, 0, 0],
      [0, 2, 0],
      [0, 1, 2],
      [1, 0, 0],
      [1, 2, 2],
      [2, 0, 0],
      [2, 2, 0],
      [0, 0, 2],
    ]),
    confirmedMineIds: ids([
      [1, 1, 1],
      [2, 0, 1],
      [2, 1, 2],
    ]),
    confirmedSafeIds: ids([
      [2, 2, 1],
      [2, 1, 0],
    ]),
    clueIds: ids([
      [2, 1, 1],
      [2, 2, 1],
      [2, 1, 0],
      [0, 0, 1],
      [0, 2, 2],
      [1, 1, 0],
      [1, 2, 1],
      [2, 2, 2],
      [1, 0, 2],
      [1, 2, 0],
      [0, 1, 1],
      [2, 0, 2],
    ]),
    liarId: id(2, 1, 1),
    liarOffset: -1,
  },
  3: {
    info: LEVELS[2],
    mineIds: ids([
      [0, 2, 1],
      [1, 1, 1],
      [1, 2, 2],
      [0, 0, 0],
      [2, 0, 0],
      [2, 1, 2],
      [0, 1, 0],
      [2, 2, 2],
      [1, 0, 2],
      [0, 0, 2],
      [2, 0, 1],
      [0, 2, 0],
    ]),
    confirmedMineIds: ids([
      [0, 2, 1],
      [1, 1, 1],
      [1, 2, 2],
      [2, 0, 1],
      [2, 2, 2],
    ]),
    confirmedSafeIds: ids([
      [2, 2, 1],
      [1, 2, 0],
    ]),
    clueIds: ids([
      [1, 2, 1],
      [2, 2, 1],
      [1, 2, 0],
      [2, 1, 1],
      [0, 1, 1],
      [1, 0, 0],
      [2, 1, 0],
      [0, 1, 2],
      [2, 0, 2],
      [0, 0, 1],
      [1, 1, 2],
      [2, 2, 0],
      [1, 0, 1],
    ]),
    liarId: id(1, 2, 1),
    liarOffset: 1,
  },
};

const allCellIds = Array.from({ length: 27 }, (_, index) =>
  id(index % 3, Math.floor(index / 3) % 3, Math.floor(index / 9)),
);
const mineSet = (puzzle: Puzzle) => new Set(puzzle.mineIds);

function coordinates(cellId: string): [number, number, number] {
  const parts = cellId.split("-").map(Number);
  if (parts.length !== 3 || parts.some((part) => !Number.isInteger(part))) {
    throw new Error(`Invalid cube cell id: ${cellId}`);
  }
  return [parts[0], parts[1], parts[2]];
}

function neighbors(cellId: string): string[] {
  const [x, y, z] = coordinates(cellId);
  const points: [number, number, number][] = [
    [x - 1, y, z],
    [x + 1, y, z],
    [x, y - 1, z],
    [x, y + 1, z],
    [x, y, z - 1],
    [x, y, z + 1],
  ];
  return points
    .filter(([nx, ny, nz]) =>
      [nx, ny, nz].every((value) => value >= 0 && value <= 2),
    )
    .map(([nx, ny, nz]) => id(nx, ny, nz));
}

function honestClue(puzzle: Puzzle, cellId: string): number {
  const mines = mineSet(puzzle);
  return neighbors(cellId).filter((neighbor) => mines.has(neighbor)).length;
}

function displayedClue(puzzle: Puzzle, cellId: string): number {
  const truth = honestClue(puzzle, cellId);
  return cellId === puzzle.liarId ? truth + puzzle.liarOffset : truth;
}

function initialKnownStatuses(puzzle: Puzzle): Map<string, CellStatus> {
  const known = new Map<string, CellStatus>();
  for (const mineId of puzzle.confirmedMineIds) known.set(mineId, "mine");
  for (const safeId of puzzle.confirmedSafeIds) known.set(safeId, "safe");
  for (const clueId of puzzle.clueIds) known.set(clueId, "safe");
  return known;
}

function evidence(
  puzzle: Puzzle,
  clueId: string,
  reveals: Readonly<Record<string, CellStatus>> = {},
) {
  const known = initialKnownStatuses(puzzle);
  for (const [revealedId, status] of Object.entries(reveals)) {
    if (!allCellIds.includes(revealedId)) continue;
    known.set(revealedId, status);
  }
  const adjacent = neighbors(clueId);
  const adjacentMineCount = adjacent.filter(
    (neighbor) => known.get(neighbor) === "mine",
  ).length;
  const unknown = adjacent.filter((neighbor) => !known.has(neighbor)).length;
  return {
    neighbors: adjacent.length,
    knownMines: adjacentMineCount,
    knownSafe: adjacent.filter((neighbor) => known.get(neighbor) === "safe")
      .length,
    unknown,
    minMines: adjacentMineCount,
    maxMines: adjacentMineCount + unknown,
  };
}

export function getCellViews(
  levelId: LevelId,
  reveals: Readonly<Record<string, CellStatus>>,
): CellView[] {
  const puzzle = PUZZLES[levelId];
  const mines = mineSet(puzzle);
  const clues = new Set(puzzle.clueIds);
  const fixedMines = new Set(puzzle.confirmedMineIds);
  const fixedSafe = new Set(puzzle.confirmedSafeIds);

  return allCellIds.map((cellId) => {
    const [x, y, z] = coordinates(cellId);
    if (clues.has(cellId)) {
      return {
        id: cellId,
        x,
        y,
        z,
        kind: "clue",
        clue: displayedClue(puzzle, cellId),
      };
    }
    const status = fixedMines.has(cellId)
      ? "mine"
      : fixedSafe.has(cellId)
        ? "safe"
        : reveals[cellId] ??
          (cellId in reveals && mines.has(cellId) ? "mine" : undefined);
    if (status === "mine") return { id: cellId, x, y, z, kind: "mine" };
    if (status === "safe") return { id: cellId, x, y, z, kind: "safe" };
    return { id: cellId, x, y, z, kind: "unknown" };
  });
}

export function getScanReveal(
  levelId: LevelId,
  clueId: string,
  alreadyRevealed: readonly string[],
): { id: string; status: CellStatus } | null {
  const puzzle = PUZZLES[levelId];
  if (!puzzle.clueIds.includes(clueId)) return null;
  const known = initialKnownStatuses(puzzle);
  for (const revealedId of alreadyRevealed) {
    if (allCellIds.includes(revealedId)) known.set(revealedId, "safe");
  }
  const mines = mineSet(puzzle);
  const nextHiddenNeighbor = neighbors(clueId).find(
    (neighbor) => !known.has(neighbor),
  );
  if (!nextHiddenNeighbor) return null;
  return {
    id: nextHiddenNeighbor,
    status: mines.has(nextHiddenNeighbor) ? "mine" : "safe",
  };
}

export function getClueEvidence(
  levelId: LevelId,
  clueId: string,
  reveals: Readonly<Record<string, CellStatus>>,
) {
  const puzzle = PUZZLES[levelId];
  if (!puzzle.clueIds.includes(clueId)) {
    throw new Error(`Cell ${clueId} does not contain a displayed clue.`);
  }
  return evidence(puzzle, clueId, reveals);
}

export function isCorrectAnswer(levelId: LevelId, cellId: string): boolean {
  return PUZZLES[levelId].liarId === cellId;
}

export function getSolvedCellViews(levelId: LevelId): CellView[] {
  const puzzle = PUZZLES[levelId];
  const mines = mineSet(puzzle);
  return allCellIds.map((cellId) => {
    const [x, y, z] = coordinates(cellId);
    if (mines.has(cellId)) return { id: cellId, x, y, z, kind: "mine" };
    return {
      id: cellId,
      x,
      y,
      z,
      kind: "clue",
      clue: honestClue(puzzle, cellId),
    };
  });
}

function validatePuzzle(puzzle: Puzzle): void {
  const safe = new Set(allCellIds.filter((cellId) => !mineSet(puzzle).has(cellId)));
  if (puzzle.mineIds.length !== new Set(puzzle.mineIds).size) {
    throw new Error(`${puzzle.info.name}: duplicate mine cell.`);
  }
  if (puzzle.clueIds.length !== new Set(puzzle.clueIds).size) {
    throw new Error(`${puzzle.info.name}: duplicate clue cell.`);
  }
  if (!safe.has(puzzle.liarId) || !puzzle.clueIds.includes(puzzle.liarId)) {
    throw new Error(`${puzzle.info.name}: liar must be a displayed safe clue.`);
  }
  if (puzzle.confirmedMineIds.some((cellId) => !mineSet(puzzle).has(cellId))) {
    throw new Error(`${puzzle.info.name}: a confirmed mine is not a mine.`);
  }
  if (
    puzzle.confirmedSafeIds.some(
      (cellId) => mineSet(puzzle).has(cellId) || !allCellIds.includes(cellId),
    )
  ) {
    throw new Error(`${puzzle.info.name}: a confirmed safe cell is invalid.`);
  }
  if (
    puzzle.confirmedMineIds.some((cellId) =>
      puzzle.confirmedSafeIds.includes(cellId),
    )
  ) {
    throw new Error(`${puzzle.info.name}: a cell is marked both mine and safe.`);
  }
  if (neighbors(puzzle.liarId).some((cellId) => !initialKnownStatuses(puzzle).has(cellId))) {
    throw new Error(`${puzzle.info.name}: liar neighbors are not fully verified.`);
  }

  const changedClues = puzzle.clueIds.filter(
    (cellId) => displayedClue(puzzle, cellId) !== honestClue(puzzle, cellId),
  );
  if (changedClues.length !== 1 || changedClues[0] !== puzzle.liarId) {
    throw new Error(`${puzzle.info.name}: expected exactly one altered clue.`);
  }
  const offset = displayedClue(puzzle, puzzle.liarId) - honestClue(puzzle, puzzle.liarId);
  if (Math.abs(offset) !== 1 || displayedClue(puzzle, puzzle.liarId) < 0 || displayedClue(puzzle, puzzle.liarId) > 6) {
    throw new Error(`${puzzle.info.name}: altered clue must be off by one within 0–6.`);
  }

  const impossibleClues = puzzle.clueIds.filter((cellId) => {
    const clue = displayedClue(puzzle, cellId);
    const bounds = evidence(puzzle, cellId);
    return clue < bounds.minMines || clue > bounds.maxMines;
  });
  if (impossibleClues.length !== 1 || impossibleClues[0] !== puzzle.liarId) {
    throw new Error(
      `${puzzle.info.name}: expected one uniquely inconsistent clue; found ${impossibleClues.join(", ") || "none"}.`,
    );
  }
}

export function validatePuzzles(): void {
  if (allCellIds.length !== 27 || new Set(allCellIds).size !== 27) {
    throw new Error("The cube must contain exactly 27 unique cells.");
  }
  for (const puzzle of Object.values(PUZZLES)) validatePuzzle(puzzle);
}

validatePuzzles();

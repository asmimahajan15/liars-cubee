import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import {
  ArrowLeft, ArrowRight, AudioLines, Check, ChevronRight, CircleHelp, Crosshair, Lock,
  RotateCcw, ScanLine, ShieldCheck, Volume2, VolumeX, X, Zap,
} from 'lucide-react';
import { CubeScene } from '@/components/game/CubeScene';
import {
  LEVELS, getCellViews, getSolvedCellViews, getScanReveal, getClueEvidence, isCorrectAnswer,
  type CellStatus, type CellView,
} from '@/game/puzzles';

const queryClient = new QueryClient();
const SAVE_KEY = 'liars-cube-campaign-v2';
type Rank = 'S' | 'A' | 'B';
type SoundCue = 'select' | 'rotate' | 'scan' | 'success' | 'wrong' | 'unlock' | 'victory';

type CampaignSave = {
  unlocked: number;
  scores: Record<string, number>;
  ranks: Record<string, Rank>;
  mute: boolean;
};
type Screen = 'title' | 'game' | 'victory';

const defaultSave: CampaignSave = { unlocked: 0, scores: {}, ranks: {}, mute: false };

function readSave(): CampaignSave {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return defaultSave;
    const parsed = JSON.parse(raw) as Partial<CampaignSave>;
    const scores = Object.fromEntries(
      Object.entries(parsed.scores ?? {}).filter(
        ([key, value]) =>
          ['1', '2', '3'].includes(key) &&
          typeof value === 'number' &&
          Number.isFinite(value) &&
          value >= 0 &&
          value <= 100,
      ),
    ) as Record<string, number>;
    const ranks = Object.fromEntries(
      Object.entries(parsed.ranks ?? {}).filter(
        ([key, value]) =>
          ['1', '2', '3'].includes(key) &&
          (value === 'S' || value === 'A' || value === 'B'),
      ),
    ) as Record<string, Rank>;
    return {
      unlocked: Math.min(Math.max(Number(parsed.unlocked) || 0, 0), Math.max(LEVELS.length - 1, 0)),
      scores,
      ranks,
      mute: Boolean(parsed.mute),
    };
  } catch {
    return defaultSave;
  }
}

function App() {
  const [save, setSave] = useState<CampaignSave>(readSave);
  const [screen, setScreen] = useState<Screen>('title');
  const [levelIndex, setLevelIndex] = useState(0);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [reveals, setReveals] = useState<Record<string, CellStatus>>({});
  const [mistakes, setMistakes] = useState(0);
  const [scansUsed, setScansUsed] = useState(0);
  const [hintsUsed, setHintsUsed] = useState(0);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [feedback, setFeedback] = useState<'wrong' | null>(null);
  const [modal, setModal] = useState<'how' | 'success' | 'victory-restart' | 'play-again' | null>(null);
  const [mute, setMute] = useState(save.mute);

  const level = LEVELS[Math.min(levelIndex, LEVELS.length - 1)];
  const cells = useMemo(() => level ? getCellViews(level.id, reveals) : [], [level, reveals]);
  const selectedCell = cells.find((cell) => cell.id === selectedId && cell.kind === 'clue') ?? null;
  const evidence = level && selectedCell ? getClueEvidence(level.id, selectedCell.id, reveals) : null;
  const hints = level?.hints ?? [];
  const timePenalty = Math.min(10, Math.floor(Math.max(0, elapsedSeconds - 90) / 30));
  const score = Math.max(0, 100 - mistakes * 12 - scansUsed * 5 - hintsUsed * 8 - timePenalty);
  const rank: Rank =
    mistakes === 0 && scansUsed === 0 && hintsUsed === 0 && elapsedSeconds <= 90
      ? 'S'
      : score >= 75
        ? 'A'
        : 'B';
  const completedCount = Object.keys(save.scores).length;
  const totalScore = Object.values(save.scores).reduce((sum, value) => sum + value, 0);
  const campaignRank: Rank =
    completedCount === LEVELS.length &&
    Object.values(save.ranks).length === LEVELS.length &&
    Object.values(save.ranks).every((savedRank) => savedRank === 'S')
      ? 'S'
      : totalScore >= LEVELS.length * 75
        ? 'A'
        : 'B';
  const currentHint = hintsUsed > 0 ? hints[Math.min(hintsUsed - 1, hints.length - 1)] : null;

  useEffect(() => {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify({ ...save, mute }));
    } catch {
      // Storage can be unavailable in private browsing; the current run remains playable.
    }
  }, [save, mute]);

  useEffect(() => {
    if (screen !== 'game' || modal !== null) return;
    const timer = window.setInterval(() => setElapsedSeconds((value) => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [screen, modal]);

  const playTone = useCallback((cue: SoundCue = 'select') => {
    if (mute || typeof window === 'undefined' || !window.AudioContext) return;
    try {
      const audio = new AudioContext();
      const patterns: Record<SoundCue, { notes: number[]; wave: OscillatorType; duration: number }> = {
        select: { notes: [520], wave: 'sine', duration: 0.07 },
        rotate: { notes: [115], wave: 'triangle', duration: 0.12 },
        scan: { notes: [430, 690], wave: 'sine', duration: 0.18 },
        success: { notes: [523, 659, 784], wave: 'sine', duration: 0.42 },
        wrong: { notes: [145], wave: 'triangle', duration: 0.16 },
        unlock: { notes: [392, 523, 659], wave: 'sine', duration: 0.48 },
        victory: { notes: [392, 494, 587, 784], wave: 'sine', duration: 0.7 },
      };
      const pattern = patterns[cue];
      pattern.notes.forEach((frequency, index) => {
        const oscillator = audio.createOscillator();
        const gain = audio.createGain();
        const start = audio.currentTime + index * 0.08;
        oscillator.type = pattern.wave;
        oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.045, start + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + pattern.duration);
        oscillator.connect(gain);
        gain.connect(audio.destination);
        oscillator.start(start);
        oscillator.stop(start + pattern.duration);
        oscillator.onended = () => {
          oscillator.disconnect();
          gain.disconnect();
        };
      });
      window.setTimeout(() => void audio.close(), pattern.duration + pattern.notes.length * 0.08 + 0.1);
    } catch {
      // Audio is decorative; gameplay remains fully available without it.
    }
  }, [mute]);

  const startLevel = useCallback((index: number) => {
    const next = Math.min(Math.max(index, 0), Math.max(LEVELS.length - 1, 0));
    const target = LEVELS[next];
    setLevelIndex(next);
    setSelectedId(null);
    setReveals({});
    setMistakes(0);
    setScansUsed(0);
    setHintsUsed(0);
    setElapsedSeconds(0);
    setFeedback(null);
    setModal(null);
    setScreen('game');
  }, []);

  const verifyAnswer = () => {
    if (!level || !selectedCell) return;
    if (isCorrectAnswer(level.id, selectedCell.id)) {
      playTone('success');
      const finalScore = score;
      setSave((previous) => ({
        ...previous,
        unlocked: Math.min(Math.max(previous.unlocked, levelIndex + 1), Math.max(LEVELS.length - 1, 0)),
        scores: { ...previous.scores, [level.id]: Math.max(previous.scores[level.id] ?? 0, finalScore) },
        ranks: {
          ...previous.ranks,
          [level.id]: finalScore >= (previous.scores[level.id] ?? -1)
            ? rank
            : previous.ranks[level.id] ?? rank,
        },
      }));
      setFeedback(null);
      setModal('success');
    } else {
      playTone('wrong');
      setMistakes((value) => value + 1);
      setFeedback('wrong');
      window.setTimeout(() => setFeedback(null), 2600);
    }
  };

  const scan = () => {
    if (!level || !selectedCell || scansUsed >= level.scanLimit) return;
    const reveal = getScanReveal(level.id, selectedCell.id, Object.keys(reveals));
    if (!reveal) {
      return;
    }
    setReveals((previous) => ({ ...previous, [reveal.id]: reveal.status }));
    setScansUsed((value) => value + 1);
    playTone('scan');
  };

  const useHint = () => {
    if (hintsUsed >= hints.length) return;
    setHintsUsed((value) => value + 1);
    playTone('scan');
  };

  const resetLevel = () => {
    if (!level) return;
    setSelectedId(null);
    setReveals({});
    setMistakes(0);
    setScansUsed(0);
    setHintsUsed(0);
    setElapsedSeconds(0);
    setFeedback(null);
    setModal(null);
  };

  const continueCampaign = () => {
    if (levelIndex >= LEVELS.length - 1) {
      playTone('victory');
      setScreen('victory');
      setModal(null);
    } else {
      playTone('unlock');
      startLevel(levelIndex + 1);
    }
  };

  const restartCampaign = () => {
    setSave(defaultSave);
    setMute(false);
    setLevelIndex(0);
    setElapsedSeconds(0);
    setScreen('title');
    setModal(null);
    setSelectedId(null);
    setReveals({});
  };

  const toggleMute = () => {
    setMute((value) => !value);
  };

  if (!LEVELS.length) {
    return <main className="app-shell flex min-h-[100dvh] items-center justify-center p-6"><div className="soft-panel max-w-lg rounded-2xl p-8 text-center"><h1 className="display text-3xl">Vault offline</h1><p className="mt-3 text-sm text-[#9eacbb]">No investigation files are available yet.</p></div></main>;
  }

  return (
    <main className={`app-shell min-h-[100dvh] ${modal === 'success' ? 'completion-flash' : ''}`}>
      <div className="app-content">
        {screen === 'title' && (
          <TitleScreen
            save={save}
            mute={mute}
            onToggleMute={toggleMute}
            onPlay={() => startLevel(Math.min(save.unlocked, LEVELS.length - 1))}
            onHow={() => setModal('how')}
            onSelectLevel={startLevel}
            onRestartCampaign={() => setModal('victory-restart')}
          />
        )}
        {screen === 'game' && level && (
          <GameScreen
            level={level}
            levelIndex={levelIndex}
            cells={cells}
            selectedId={selectedId}
            selectedCell={selectedCell}
            evidence={evidence}
            reveals={reveals}
            mistakes={mistakes}
            scansUsed={scansUsed}
            hintsUsed={hintsUsed}
            elapsedSeconds={elapsedSeconds}
            score={score}
            rank={rank}
            feedback={feedback}
            currentHint={currentHint}
            hintCount={hints.length}
            mute={mute}
            celebrate={modal === 'success'}
            onSelect={(id) => { setSelectedId(id); setFeedback(null); playTone('select'); }}
            onRotate={() => playTone('rotate')}
            onVerify={verifyAnswer}
            onScan={scan}
            onHint={useHint}
            onReset={resetLevel}
            onToggleMute={toggleMute}
            onMenu={() => setScreen('title')}
          />
        )}
        {screen === 'victory' && (
          <VictoryScreen
            totalScore={totalScore}
            completedCount={completedCount}
            campaignRank={campaignRank}
            cells={getSolvedCellViews(3)}
            onPlayAgain={() => setModal('play-again')}
            onMenu={() => setScreen('title')}
          />
        )}
      </div>
      {modal && (
        <Modal onClose={() => setModal(null)} labelledBy="modal-heading">
          {modal === 'how' && <HowToPlay onClose={() => setModal(null)} />}
          {modal === 'success' && level && (
            <SuccessContent
              levelName={level.name}
              levelIndex={levelIndex}
              score={score}
              rank={rank}
              elapsedSeconds={elapsedSeconds}
              clueCoordinates={
                selectedCell
                  ? `X${selectedCell.x + 1} · Y${selectedCell.y + 1} · Z${selectedCell.z + 1}`
                  : '—'
              }
              displayedCount={selectedCell?.clue ?? 0}
              verifiedCount={evidence?.minMines ?? 0}
              mistakes={mistakes}
              scansUsed={scansUsed}
              hintsUsed={hintsUsed}
              isLast={levelIndex === LEVELS.length - 1}
              onContinue={continueCampaign}
              onReplay={resetLevel}
            />
          )}
          {(modal === 'victory-restart' || modal === 'play-again') && (
            <ConfirmContent
              title={modal === 'play-again' ? 'Play the campaign again?' : 'Restart the campaign?'}
              body={modal === 'play-again' ? 'Your saved scores and unlocked files will be cleared before the first investigation begins.' : 'Your unlocked levels and saved scores will be erased. This cannot be undone.'}
              confirm={modal === 'play-again' ? 'Restart campaign' : 'Erase progress'}
              onCancel={() => setModal(null)}
              onConfirm={modal === 'play-again' ? () => { restartCampaign(); startLevel(0); } : restartCampaign}
            />
          )}
        </Modal>
      )}
    </main>
  );
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3" data-testid="brand-mark">
      <div className="relative flex h-9 w-9 items-center justify-center border border-[#d0a64f]/50 bg-[#d0a64f]/[.08] text-[#e0bd70]">
        <div className="h-4 w-4 rotate-45 border border-current" />
        <div className="absolute h-1.5 w-1.5 rounded-full bg-current" />
      </div>
      <div>
        <div className="display text-[13px] font-semibold tracking-[.16em] text-[#e9e3d6]">LIAR'S CUBE</div>
        {!compact && <div className="mono mt-0.5 text-[8px] text-[#738399]">THE DECEPTION PROTOCOL</div>}
      </div>
    </div>
  );
}

function TitleScreen({
  save, mute, onToggleMute, onPlay, onHow, onSelectLevel, onRestartCampaign,
}: {
  save: CampaignSave;
  mute: boolean;
  onToggleMute: () => void;
  onPlay: () => void;
  onHow: () => void;
  onSelectLevel: (index: number) => void;
  onRestartCampaign: () => void;
}) {
  return (
    <div className="mx-auto min-h-[100dvh] max-w-[1440px] px-5 pb-12 pt-6 sm:px-9 lg:px-14">
      <header className="flex items-center justify-between">
        <Brand />
        <button onClick={onToggleMute} className="quiet-button inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-[#96a5b6]" aria-label={mute ? 'Enable sound' : 'Mute sound'} data-testid="button-mute">
          {mute ? <VolumeX size={16} /> : <Volume2 size={16} />}
        </button>
      </header>
      <section className="grid min-h-[calc(100dvh-100px)] items-center gap-9 pt-12 lg:grid-cols-[1.02fr_.98fr] lg:gap-6 lg:pt-0">
        <div className="fade-up max-w-[610px]">
          <p className="eyebrow mb-5 flex items-center gap-3 text-[10px] text-[#d4ad5d]"><span className="h-px w-8 bg-[#d4ad5d]/60" /> CASE FILE 000 — CLASSIFIED</p>
          <h1 className="display text-[clamp(3.5rem,8vw,7rem)] font-semibold leading-[.87] text-[#f0ede5]">
            LIAR'S<br /><span className="text-[#d9b968]">CUBE</span>
          </h1>
          <p className="mono mt-5 text-[11px] tracking-[.19em] text-[#aebbc9] sm:text-[13px]">TRUST NOTHING. VERIFY EVERYTHING.</p>
          <div className="mt-9 max-w-[420px] border-l border-[#cda452]/50 pl-5">
            <p className="display text-[15px] font-semibold text-[#e1c77f]">One clue lies in every cube. Find the contradiction.</p>
            <p className="text-[15px] leading-7 text-[#b3bfca]">An unknown intelligence has corrupted the vault's logic. Find the false signal and unlock the next chamber.</p>
            <p className="mono mt-3 text-[9px] tracking-[.11em] text-[#64758a]">A LOGIC INVESTIGATION IN THREE ACTS</p>
          </div>
          <div className="mt-9 flex flex-wrap items-center gap-3">
            <button onClick={onPlay} className="gold-button inline-flex h-12 items-center gap-3 rounded-md px-6 text-[11px] font-bold tracking-[.13em]" data-testid="button-play-investigation">
              <Crosshair size={16} /> PLAY INVESTIGATION <ArrowRight size={15} />
            </button>
            <button onClick={onHow} className="quiet-button inline-flex h-12 items-center gap-2 rounded-md border border-white/10 px-5 text-[11px] font-semibold tracking-[.08em] text-[#b2bdc8]" data-testid="button-how-to-play">
              <CircleHelp size={15} /> HOW TO PLAY
            </button>
          </div>
        </div>
        <div className="fade-up fade-delay-2 relative mx-auto flex w-full max-w-[660px] items-center justify-center">
          <div className="absolute inset-[9%] rounded-full border border-[#748da7]/10" />
          <div className="absolute inset-[18%] rounded-full border border-dashed border-[#748da7]/10" />
          <div className="absolute right-[8%] top-[18%] rotate-90 mono text-[8px] tracking-[.2em] text-[#586a7d]">VAULT NODE 03</div>
          <div className="relative w-full">
            <TitleCube />
          </div>
          <div className="absolute bottom-[9%] left-[8%] flex items-center gap-2 mono text-[8px] tracking-[.12em] text-[#657689]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#62b89b] shadow-[0_0_12px_rgba(98,184,155,.45)]" /> SYSTEM INTEGRITY: COMPROMISED
          </div>
        </div>
      </section>
      <section className="fade-up fade-delay-3 border-t border-white/[.08] pt-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="eyebrow text-[9px] text-[#73849a]">INVESTIGATION FILES</div>
          <div className="mono text-[9px] text-[#75859a]" data-testid="text-campaign-progress">PROGRESS <span className="text-[#d5b66d]">{String(completedLevelCount(save)).padStart(2, '0')}</span> / {String(LEVELS.length).padStart(2, '0')}</div>
        </div>
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
          {LEVELS.map((item, index) => {
            const unlocked = index <= save.unlocked;
            const best = save.scores[item.id];
            return (
              <button
                key={item.id}
                disabled={!unlocked}
                onClick={() => onSelectLevel(index)}
                className={`group flex min-h-[70px] items-center gap-3 rounded-lg border px-3.5 text-left transition-colors ${unlocked ? 'border-white/[.09] bg-white/[.025] hover:border-[#d0a64f]/40 hover:bg-[#d0a64f]/[.04]' : 'cursor-not-allowed border-white/[.045] bg-black/10 opacity-55'}`}
                data-testid={`button-level-${index + 1}`}
              >
                <span className={`mono text-[10px] ${best !== undefined ? 'text-[#69b99a]' : 'text-[#64758a]'}`}>{String(index + 1).padStart(2, '0')}</span>
                <span className="min-w-0 flex-1">
                  <span className="block display text-sm font-semibold text-[#d8e0e6]">{item.name}</span>
                  <span className="mt-1 block truncate text-[10px] text-[#75869a]">{best !== undefined ? `CLEARED · ${best} PTS` : item.theme}</span>
                </span>
                {best !== undefined ? <Check size={14} className="text-[#69b99a]" /> : unlocked ? <ChevronRight size={14} className="text-[#7e8d9c] transition-transform group-hover:translate-x-1" /> : <Lock size={13} className="text-[#687688]" />}
              </button>
            );
          })}
        </div>
      </section>
      <footer className="mt-8 flex flex-wrap items-center justify-between gap-3 mono text-[8px] tracking-[.1em] text-[#536477]">
        <span>FICTIONAL VAULT SYSTEM // OFFLINE PROTOCOL</span>
        <div className="flex items-center gap-5"><span>NO SIGNAL REQUIRED</span>{completedLevelCount(save) > 0 && <button onClick={onRestartCampaign} className="text-[#718195] hover:text-[#d9b968]" data-testid="button-restart-campaign">RESET CAMPAIGN</button>}</div>
      </footer>
    </div>
  );
}

function completedLevelCount(save: CampaignSave) {
  return Object.keys(save.scores).length;
}

function TitleCube() {
  return (
    <svg viewBox="0 0 500 450" className="title-cube-art relative z-10 w-full overflow-visible" aria-hidden="true">
      <defs>
        <linearGradient id="blockFace" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#30445a" /><stop offset="1" stopColor="#172536" /></linearGradient>
        <linearGradient id="blockSide" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#1b2b3d" /><stop offset="1" stopColor="#101b29" /></linearGradient>
        <filter id="cubeShadow"><feGaussianBlur stdDeviation="18" /></filter>
      </defs>
      <ellipse cx="260" cy="385" rx="155" ry="22" fill="#03070d" opacity=".6" filter="url(#cubeShadow)" />
      <g transform="translate(65 28)" stroke="#7b96ad" strokeOpacity=".42" strokeWidth="1.2">
        {Array.from({ length: 3 }, (_, z) => Array.from({ length: 3 }, (_, y) => Array.from({ length: 3 }, (_, x) => {
          const px = 137 + x * 68 - z * 45;
          const py = 53 + y * 68 + z * 26;
          const special = (x === 1 && y === 1 && z === 0) || (x === 2 && y === 1 && z === 1);
          return (
            <g key={`${x}${y}${z}`} transform={`translate(${px} ${py})`}>
              <path d="M0 0l44-24 44 24-44 25z" fill={special ? '#604e31' : 'url(#blockFace)'} />
              <path d="M0 0l44 25v48L0 48z" fill={special ? '#3b382f' : 'url(#blockSide)'} />
              <path d="M88 0L44 25v48l44-25z" fill="#111e2d" />
              {special && <text x="44" y="17" textAnchor="middle" fill="#e4c478" stroke="none" fontFamily="DM Mono, monospace" fontSize="19">{x === 1 ? '4' : '2'}</text>}
              {x === 0 && y === 0 && z === 0 && <circle cx="44" cy="47" r="5" fill="#d7a94f" stroke="none" />}
            </g>
          );
        })))}
      </g>
      <path d="M43 354h412" stroke="#738aa0" strokeOpacity=".16" />
      <path d="M118 374h274" stroke="#d0a64f" strokeOpacity=".25" strokeDasharray="2 9" />
      <circle cx="250" cy="242" r="203" fill="none" stroke="#718aa1" strokeOpacity=".07" strokeDasharray="2 8" />
    </svg>
  );
}

type GameScreenProps = {
  level: (typeof LEVELS)[number];
  levelIndex: number;
  cells: CellView[];
  selectedId: string | null;
  selectedCell: CellView | null;
  evidence: ReturnType<typeof getClueEvidence> | null;
  reveals: Record<string, CellStatus>;
  mistakes: number;
  scansUsed: number;
  hintsUsed: number;
  elapsedSeconds: number;
  score: number;
  rank: Rank;
  feedback: 'wrong' | null;
  currentHint: string | undefined | null;
  hintCount: number;
  mute: boolean;
  celebrate: boolean;
  onSelect: (id: string) => void;
  onRotate: () => void;
  onVerify: () => void;
  onScan: () => void;
  onHint: () => void;
  onReset: () => void;
  onToggleMute: () => void;
  onMenu: () => void;
};

function GameScreen(props: GameScreenProps) {
  const {
    level, levelIndex, cells, selectedId, selectedCell, evidence, reveals, mistakes,
    scansUsed, hintsUsed, elapsedSeconds, score, rank, feedback, currentHint, hintCount, mute, celebrate,
    onSelect, onRotate, onVerify, onScan, onHint, onReset, onToggleMute, onMenu,
  } = props;
  const clueCells = cells.filter((cell) => cell.kind === 'clue');
  const scanRemaining = Math.max(0, level.scanLimit - scansUsed);
  const elapsedLabel = `${String(Math.floor(elapsedSeconds / 60)).padStart(2, '0')}:${String(elapsedSeconds % 60).padStart(2, '0')}`;
  return (
    <div className="mx-auto min-h-[100dvh] max-w-[1600px] px-4 pb-8 pt-4 sm:px-7 lg:px-10">
      <header className="flex min-h-12 items-center justify-between border-b border-white/[.08] pb-4">
        <div className="flex items-center gap-5">
          <button onClick={onMenu} className="quiet-button flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-[#95a4b5]" aria-label="Return to case files" data-testid="button-return-menu"><ArrowLeft size={16} /></button>
          <Brand compact />
          <div className="hidden h-6 w-px bg-white/10 sm:block" />
          <span className="hidden mono text-[9px] text-[#718196] sm:block">CASE {String(levelIndex + 1).padStart(2, '0')} / {String(LEVELS.length).padStart(2, '0')}</span>
        </div>
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-2 rounded-full border border-white/[.08] px-3 py-2"><span className="mono text-[9px] text-[#8796a6]">TIME <b className="ml-1 text-[#e1c277]" data-testid="text-elapsed-time">{elapsedLabel}</b></span></div>
          <div className="hidden items-center gap-2 rounded-full border border-white/[.08] px-3 py-2 sm:flex"><span className="h-1.5 w-1.5 rounded-full bg-[#cfaa5d]" /><span className="mono text-[9px] text-[#8796a6]">RANK <b className="ml-1 text-[#e1c277]">{rank}</b></span></div>
          <button onClick={onToggleMute} className="quiet-button flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-[#95a4b5]" aria-label={mute ? 'Enable sound' : 'Mute sound'} data-testid="button-mute-game">{mute ? <VolumeX size={15} /> : <Volume2 size={15} />}</button>
          <button onClick={onReset} className="quiet-button flex h-9 items-center gap-2 rounded-full border border-white/10 px-3 text-[10px] text-[#aab6c2]" data-testid="button-reset-level"><RotateCcw size={13} /><span className="hidden sm:inline">RESET</span></button>
        </div>
      </header>
      {level.id === 1 && (
        <div className="mt-4 flex items-start gap-3 rounded-lg border border-[#d2ac5c]/20 bg-[#d2ac5c]/[.045] px-4 py-3 text-xs leading-5 text-[#d2c49f]" role="note" data-testid="status-tutorial-hint">
          <Zap size={14} className="mt-0.5 shrink-0 text-[#d5b15e]" />
          <span>Tutorial: a clue is impossible when its displayed count falls outside the verified minimum–maximum range.</span>
        </div>
      )}
      <div className="grid gap-6 pt-5 lg:grid-cols-[minmax(0,1fr)_350px] xl:gap-10">
        <section className="min-w-0">
          <div className="mb-2 flex items-end justify-between">
            <div>
              <p className="eyebrow text-[9px] text-[#d2ac5f]">INVESTIGATION {String(levelIndex + 1).padStart(2, '0')}</p>
              <h1 className="display mt-1 text-2xl font-semibold text-[#e5e7e2] sm:text-3xl" data-testid="text-level-name">{level.name}</h1>
              <p className="mt-1 text-xs text-[#8191a3]">{level.tagline}</p>
            </div>
            <div className="hidden text-right sm:block"><span className="mono text-[8px] text-[#65768a]">SCORE / 100</span><div className="evidence-number mt-1 text-lg text-[#d5b66d]" data-testid="text-level-score">{score}</div></div>
          </div>
          <div className="relative mt-1 overflow-hidden rounded-2xl border border-white/[.07] bg-[#0c1420]/35">
            <div className="absolute left-4 top-4 z-10 flex items-center gap-2 rounded-full border border-white/[.08] bg-[#111b28]/75 px-3 py-2 backdrop-blur">
              <span className="relative h-1.5 w-1.5 rounded-full bg-[#d3ad5f]"><span className="absolute inset-0 animate-ping rounded-full bg-[#d3ad5f] opacity-40" /></span>
              <span className="mono text-[8px] tracking-[.14em] text-[#94a2b0]">VAULT MODEL · 3×3×3</span>
            </div>
            <CubeScene key={level.id} cells={cells} selectedId={selectedId} reveals={reveals} onSelect={onSelect} onRotate={onRotate} celebrate={celebrate} stage={level.id} />
            <div className="absolute right-4 top-4 z-10 rounded-md border border-white/[.08] bg-[#111b28]/75 px-3 py-2 backdrop-blur">
              <div className="mono text-[8px] tracking-[.12em] text-[#74869a]">SELECTABLE CLUES</div>
              <div className="mt-1 text-right evidence-number text-xs text-[#e1c577]" data-testid="text-clue-count">{clueCells.length}</div>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-white/[.07] pt-4">
            <div className="flex items-center gap-2 text-xs text-[#93a1af]"><span className="flex h-7 w-7 items-center justify-center rounded-md border border-[#d1a756]/25 bg-[#d1a756]/[.07] text-[#d4b365]"><ShieldCheck size={14} /></span>Exactly one clue is corrupted.</div>
            <div className="flex items-center gap-3 mono text-[8px] text-[#728196]"><span>FAILURES <b className="text-[#e17c70]" data-testid="text-mistakes">{mistakes}</b></span><span className="h-3 w-px bg-white/10" /><span>SCANS <b className="text-[#7dc4a6]" data-testid="text-scans">{scansUsed}/{level.scanLimit}</b></span><span className="h-3 w-px bg-white/10" /><span>HINTS <b className="text-[#d4b365]" data-testid="text-hints">{hintsUsed}/{hintCount}</b></span></div>
          </div>
        </section>

        <aside className="flex min-w-0 flex-col gap-3">
          <div className="soft-panel rounded-xl p-4 sm:p-5">
            <div className="flex items-center justify-between">
              <div><p className="eyebrow text-[8px] text-[#8392a3]">CURRENT TARGET</p><h2 className="display mt-1 text-lg font-semibold text-[#e0e4e3]">Clue analysis</h2></div>
              <div className="mono rounded border border-[#d5ad5d]/25 px-2 py-1 text-[9px] text-[#d8ba73]">01 / 01</div>
            </div>
            {selectedCell && evidence ? (
              <>
                <div className="mt-4 flex items-center justify-between rounded-lg border border-white/[.08] bg-[#0c1420]/65 px-3.5 py-3" data-testid="status-selected-clue">
                  <div><div className="mono text-[8px] text-[#718298]">SELECTED CLUE</div><div className="mt-1 display text-[15px] font-semibold text-[#efcf84]">COUNT {selectedCell.clue}</div></div>
                  <div className="text-right"><div className="mono text-[8px] text-[#718298]">COORDINATES</div><div className="evidence-number mt-1 text-[11px] text-[#c0cbd3]" data-testid="text-selected-coordinates">X{selectedCell.x + 1} · Y{selectedCell.y + 1} · Z{selectedCell.z + 1}</div></div>
                </div>
                <div className="mt-4">
                  <div className="mb-2 flex items-center justify-between"><span className="eyebrow text-[8px] text-[#78899d]">NEIGHBOR EVIDENCE</span><span className="mono text-[8px] text-[#68798b]">{evidence.neighbors} ADJACENT CELLS</span></div>
                  <div className="grid grid-cols-4 gap-1.5">
                    <EvidenceTile label="MINES" value={evidence.knownMines} tone="coral" testId="evidence-known-mines" />
                    <EvidenceTile label="SAFE" value={evidence.knownSafe} tone="mint" testId="evidence-known-safe" />
                    <EvidenceTile label="UNKNOWN" value={evidence.unknown} tone="plain" testId="evidence-unknown" />
                    <EvidenceTile label="COUNT" value={selectedCell.clue ?? '—'} tone="gold" testId="evidence-clue-count" />
                  </div>
                  <div className="mt-3 rounded-md border border-white/[.07] bg-black/10 px-3 py-2">
                    <div className="flex items-center justify-between mono text-[8px] text-[#8391a0]">
                      <span>POSSIBLE MINE RANGE</span><span className="evidence-number text-[#c5d0d9]" data-testid="text-evidence-range">{evidence.minMines} — {evidence.maxMines}</span>
                    </div>
                    <div className="mt-2 h-1 overflow-hidden rounded-full bg-[#263445]"><div className="level-line h-full rounded-full" style={{ width: `${Math.min(100, ((evidence.maxMines - evidence.minMines + 1) / (evidence.neighbors + 1)) * 100)}%` }} /></div>
                  </div>
                  {Object.entries(reveals).length > 0 && (
                    <div className="mt-3 space-y-1.5" data-testid="list-scan-reveals">
                      {Object.entries(reveals).map(([id, status]) => {
                        const revealedCell = cells.find((cell) => cell.id === id);
                        if (!revealedCell) return null;
                        return <div key={id} className="flex items-center justify-between rounded-md border border-[#75b99d]/15 bg-[#5ca98d]/[.045] px-3 py-2 text-[9px]" data-testid={`status-scan-reveal-${id}`}>
                          <span className="mono text-[#8191a1]">CELL X{revealedCell.x + 1} · Y{revealedCell.y + 1} · Z{revealedCell.z + 1}</span>
                          <span className={`mono font-medium tracking-[.1em] ${status === 'safe' ? 'text-[#8dd0af]' : 'text-[#e28b82]'}`}>{status.toUpperCase()}</span>
                        </div>;
                      })}
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="mt-4 rounded-lg border border-dashed border-white/10 px-4 py-6 text-center text-xs text-[#8291a2]" data-testid="status-no-clue">Select a numbered clue on the cube to inspect its neighborhood.</div>
            )}
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button onClick={onScan} disabled={!selectedCell || !evidence || evidence.unknown === 0 || scanRemaining <= 0} className="quiet-button flex min-h-[42px] items-center justify-center gap-2 rounded-md border border-[#70b89e]/25 bg-[#58a88b]/[.06] px-3 text-[10px] font-semibold tracking-[.06em] text-[#94d0b7] disabled:cursor-not-allowed disabled:opacity-40" data-testid="button-scan">
                <ScanLine size={14} /> SCAN <span className="mono text-[8px]">{scanRemaining} LEFT</span>
              </button>
              <button onClick={onHint} disabled={hintsUsed >= hintCount} className="quiet-button flex min-h-[42px] items-center justify-center gap-2 rounded-md border border-[#d2a854]/25 bg-[#d2a854]/[.05] px-3 text-[10px] font-semibold tracking-[.06em] text-[#e0c37b] disabled:cursor-not-allowed disabled:opacity-40" data-testid="button-hint">
                <Zap size={14} /> HINT <span className="mono text-[8px]">{Math.max(0, hintCount - hintsUsed)}</span>
              </button>
            </div>
            {currentHint && <div className="mt-3 flex gap-2 rounded-md border border-[#d2a854]/20 bg-[#d2a854]/[.045] p-3 text-xs leading-5 text-[#d2c49f]" data-testid="status-hint"><Zap size={13} className="mt-0.5 shrink-0 text-[#d5b15e]" /><span>{currentHint}</span></div>}
            {feedback === 'wrong' && <div role="status" className="mt-3 flex items-start gap-2 rounded-md border border-[#d9776b]/25 bg-[#8f3934]/[.12] p-3 text-xs leading-5 text-[#e6a198]" data-testid="status-wrong-answer"><X size={14} className="mt-0.5 shrink-0" /><span>That conclusion doesn't hold. Recheck the evidence and try another clue.</span></div>}
            <button onClick={onVerify} disabled={!selectedCell} className="gold-button mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-md text-[10px] font-bold tracking-[.13em] disabled:cursor-not-allowed disabled:opacity-40" data-testid="button-verify">
              <Crosshair size={15} /> VERIFY THIS CLUE <ArrowRight size={14} />
            </button>
          </div>
          <div className="soft-panel rounded-xl p-4">
            <div className="flex items-center justify-between"><div className="eyebrow text-[8px] text-[#8191a3]">FIELD NOTES</div><span className="mono text-[8px] text-[#64768a]">RELIABLE DATA</span></div>
            <p className="mt-2 text-[11px] leading-5 text-[#8f9eae]">Scan: one hidden neighbor status, never the answer. Score / 100: −12 per miss, −5 per scan, −8 per hint, then −1 per 30 seconds after 90 seconds. S: no misses or aids within 90 seconds; A: 75+; B: below 75.</p>
            <button onClick={() => document.getElementById('field-legend')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' })} className="mt-3 flex items-center gap-2 text-[9px] text-[#c2ac73] hover:text-[#ead18c]" data-testid="button-evidence-key"><CircleHelp size={12} /> EVIDENCE KEY</button>
          </div>
          <div id="field-legend" className="flex items-center gap-4 rounded-lg border border-white/[.07] bg-black/10 px-3 py-2.5">
            <span className="mono text-[8px] text-[#6f8195]">KEY</span>
            <span className="flex items-center gap-1.5 text-[9px] text-[#9cacb9]"><i className="h-1.5 w-1.5 rounded-full bg-[#d1a85b]" /> Clue</span>
            <span className="flex items-center gap-1.5 text-[9px] text-[#9cacb9]"><i className="h-1.5 w-1.5 rounded-full bg-[#72c0a1]" /> Safe</span>
            <span className="flex items-center gap-1.5 text-[9px] text-[#9cacb9]"><i className="h-1.5 w-1.5 rounded-full bg-[#dc7770]" /> Mine</span>
          </div>
          <div className="mt-auto pt-1 mono text-[8px] tracking-[.07em] text-[#55677c]"><AudioLines size={12} className="mr-1.5 inline text-[#75899c]" /> PROTOCOL SCORE <span className="float-right evidence-number text-[#d5b76e]">{score} · {rank}</span></div>
        </aside>
      </div>
    </div>
  );
}

function EvidenceTile({ label, value, tone, testId }: { label: string; value: number | string; tone: string; testId: string }) {
  const color = tone === 'coral' ? 'text-[#df8980]' : tone === 'mint' ? 'text-[#83c5a6]' : tone === 'gold' ? 'text-[#e2c274]' : 'text-[#bbc6cf]';
  return <div className="rounded-md border border-white/[.06] bg-black/10 px-2 py-2 text-center" data-testid={testId}><div className={`evidence-number text-[15px] ${color}`}>{value}</div><div className="mono mt-1 text-[7px] tracking-[.07em] text-[#718194]">{label}</div></div>;
}

function Modal({ children, onClose, labelledBy }: { children: ReactNode; onClose: () => void; labelledBy: string }) {
  useEffect(() => {
    const listener = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', listener);
    return () => window.removeEventListener('keydown', listener);
  }, [onClose]);
  return (
    <div className="modal-backdrop fixed inset-0 z-50 flex items-center justify-center p-4" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section role="dialog" aria-modal="true" aria-labelledby={labelledBy} className="soft-panel fade-up relative w-full max-w-[480px] rounded-2xl p-6 sm:p-8" data-testid="dialog-modal">
        <button onClick={onClose} aria-label="Close dialog" className="quiet-button absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full border border-white/10 text-[#9ba8b5]" data-testid="button-close-modal"><X size={15} /></button>
        {children}
      </section>
    </div>
  );
}

function HowToPlay({ onClose }: { onClose: () => void }) {
  const steps = [
    { number: '01', title: 'TURN THE VAULT', body: 'Drag the 3D cube to inspect its faces. Select a numbered clue to examine its cell and coordinates.' },
    { number: '02', title: 'COUNT FACE NEIGHBORS', body: 'A clue counts mines only in cells that share a face with it, never cells that touch only at an edge or corner.' },
    { number: '03', title: 'CHECK THE RANGE', body: 'Known mines give the minimum possible count. Add unknown neighboring cells to get the maximum. A number outside that range is impossible.' },
    { number: '04', title: 'FIND THE LIE', body: 'Exactly one displayed clue has been changed by one. Use the verified mine/safe marks and optional scans to find the contradiction.' },
    { number: '05', title: 'VERIFY YOUR DEDUCTION', body: 'Select the inconsistent clue and verify it to clear the chamber. Mistakes, scans, hints and time affect your score.' },
  ];
  return (
    <>
      <p className="eyebrow text-[9px] text-[#d2ad61]">FIELD MANUAL / 05 STEPS</p>
      <h2 id="modal-heading" className="display mt-2 text-3xl font-semibold">How to play</h2>
      <p className="mt-2 text-sm leading-6 text-[#9ba9b7]">One claim is fabricated. Your job is to isolate it without trusting the vault's own voice.</p>
      <div className="mt-6 space-y-3">
        {steps.map((step) => <div key={step.number} className="flex gap-4 rounded-lg border border-white/[.07] bg-black/10 p-4"><span className="mono pt-0.5 text-[10px] text-[#d4b360]">{step.number}</span><div><h3 className="display text-sm font-semibold tracking-[.06em] text-[#e0e4e3]">{step.title}</h3><p className="mt-1 text-xs leading-5 text-[#8998a8]">{step.body}</p></div></div>)}
      </div>
      <div className="mt-5 grid grid-cols-2 gap-2 text-[10px] leading-5 text-[#9ba9b7]">
        <div className="rounded-lg border border-white/[.07] p-3"><b className="text-[#83c5a6]">SCAN</b><br />Reveal one hidden neighbor's safe/mine status. Limited per case; it never marks a clue as false.</div>
        <div className="rounded-lg border border-white/[.07] p-3"><b className="text-[#e0c274]">HINT</b><br />Progressive deduction help, with a scoring cost.</div>
      </div>
      <button onClick={onClose} className="gold-button mt-6 flex h-11 w-full items-center justify-center gap-2 rounded-md text-[10px] font-bold tracking-[.12em]" data-testid="button-close-how">UNDERSTOOD <Check size={14} /></button>
    </>
  );
}

function SuccessContent({
  levelName, levelIndex, score, rank, elapsedSeconds, clueCoordinates, displayedCount,
  verifiedCount, mistakes, scansUsed, hintsUsed, isLast, onContinue, onReplay,
}: {
  levelName: string; levelIndex: number; score: number; rank: Rank; elapsedSeconds: number;
  clueCoordinates: string; displayedCount: number; verifiedCount: number;
  mistakes: number; scansUsed: number; hintsUsed: number;
  isLast: boolean; onContinue: () => void; onReplay: () => void;
}) {
  return (
    <>
      <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full border border-[#70bb9c]/30 bg-[#57a889]/10 text-[#86c9aa]"><ShieldCheck size={23} /></div>
      <p className="eyebrow text-[9px] text-[#80c2a2]">CONTRADICTION CONFIRMED / FILE {String(levelIndex + 1).padStart(2, '0')}</p>
      <h2 id="modal-heading" className="display mt-2 text-3xl font-semibold">The lie is exposed.</h2>
      <p className="mt-2 text-sm text-[#9ba9b7]">You isolated the corrupted clue in <span className="text-[#ddd9cc]">{levelName}</span>.</p>
      <div className="mt-4 rounded-lg border border-[#74bd9e]/15 bg-[#57a889]/[.045] p-3 text-xs leading-5 text-[#b7c8c5]" data-testid="status-solution-explanation">
        <span className="mono text-[9px] text-[#82c5a6]">{clueCoordinates}</span>
        <p className="mt-1">Its verified neighbors contain {verifiedCount} mine{verifiedCount === 1 ? '' : 's'}, but the clue claimed {displayedCount}. The true mine layout is now unsealed.</p>
      </div>
      <div className="mt-6 flex items-center justify-between rounded-xl border border-[#d2ac5c]/20 bg-[#d2ac5c]/[.06] p-4">
        <div><div className="mono text-[8px] tracking-[.15em] text-[#8d9aa5]">CASE SCORE / 100</div><div className="score-flash evidence-number mt-1 text-3xl text-[#e4c879]" data-testid="text-success-score">{score}</div></div>
        <div className="text-right"><div className="mono text-[8px] tracking-[.15em] text-[#8d9aa5]">FIELD RANK</div><div className="display mt-1 text-3xl font-semibold text-[#e4c879]" data-testid="text-success-rank">{rank}</div></div>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Stat label="MISSES" value={mistakes} />
        <Stat label="SCANS" value={scansUsed} />
        <Stat label="HINTS" value={hintsUsed} />
        <Stat label="SECONDS" value={elapsedSeconds} />
      </div>
      <div className="mt-6 flex gap-2">
        <button onClick={onReplay} className="quiet-button flex h-11 items-center justify-center gap-2 rounded-md border border-white/10 px-4 text-[9px] font-semibold tracking-[.09em] text-[#adb9c4]" data-testid="button-replay-level"><RotateCcw size={13} /> REPLAY</button>
        <button onClick={onContinue} className="gold-button flex h-11 flex-1 items-center justify-center gap-2 rounded-md text-[10px] font-bold tracking-[.11em]" data-testid="button-continue">{isLast ? 'VIEW CAMPAIGN RESULTS' : 'CONTINUE'} <ArrowRight size={14} /></button>
      </div>
    </>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return <div className="rounded-lg border border-white/[.07] bg-black/10 p-3 text-center"><div className="evidence-number text-lg text-[#c0cbd2]">{value}</div><div className="mono mt-1 text-[7px] text-[#718296]">{label}</div></div>;
}

function ConfirmContent({ title, body, confirm, onCancel, onConfirm }: { title: string; body: string; confirm: string; onCancel: () => void; onConfirm: () => void }) {
  return (
    <>
      <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-full border border-[#d3a952]/25 bg-[#d3a952]/[.07] text-[#d7b568]"><RotateCcw size={18} /></div>
      <p className="eyebrow text-[9px] text-[#d2ad61]">CONFIRM ACTION</p>
      <h2 id="modal-heading" className="display mt-2 text-2xl font-semibold">{title}</h2>
      <p className="mt-3 text-sm leading-6 text-[#9ba9b7]">{body}</p>
      <div className="mt-6 flex gap-2">
        <button onClick={onCancel} className="quiet-button h-11 flex-1 rounded-md border border-white/10 text-[10px] font-semibold tracking-[.09em] text-[#aeb9c4]" data-testid="button-cancel-confirm">KEEP INVESTIGATING</button>
        <button onClick={onConfirm} className="h-11 rounded-md border border-[#d7776b]/30 bg-[#a9443e]/20 px-4 text-[10px] font-bold tracking-[.08em] text-[#eda39a] hover:bg-[#a9443e]/30" data-testid="button-confirm-action">{confirm.toUpperCase()}</button>
      </div>
    </>
  );
}

function VictoryScreen({
  totalScore, completedCount, campaignRank, cells, onPlayAgain, onMenu,
}: {
  totalScore: number; completedCount: number; campaignRank: Rank; cells: CellView[];
  onPlayAgain: () => void; onMenu: () => void;
}) {
  return (
    <div className="mx-auto grid min-h-[100dvh] max-w-[1400px] items-center gap-4 px-4 py-8 sm:px-8 lg:grid-cols-[1.05fr_.95fr] lg:gap-12 lg:px-12">
      <div className="relative overflow-hidden rounded-2xl border border-white/[.08] bg-[#0c1420]/35" data-testid="scene-vault-opening">
        <CubeScene key="vault-victory" cells={cells} selectedId={null} reveals={{}} opened stage={3} onSelect={() => undefined} onRotate={() => undefined} />
        <div className="absolute left-4 top-4 z-10 rounded-full border border-[#d2ac5c]/20 bg-[#111b28]/80 px-3 py-2 mono text-[8px] tracking-[.12em] text-[#d7bd79]">VAULT CORE — DECRYPTED</div>
      </div>
      <div className="fade-up max-w-xl py-4">
        <div className="mb-7 flex h-14 w-14 items-center justify-center rounded-full border border-[#d2ac5c]/35 bg-[#d2ac5c]/[.07] text-[#e2c477]"><ShieldCheck size={25} /></div>
        <p className="eyebrow text-[10px] text-[#d4b365]">PROTOCOL COMPLETE / VAULT UNSEALED</p>
        <h1 className="display mt-4 text-[clamp(3rem,7vw,6rem)] font-semibold leading-[.9]" data-testid="text-final-victory">THE DECEPTION<br /><span className="text-[#d9b968]">IS BROKEN.</span></h1>
        <p className="mt-5 max-w-md text-sm leading-6 text-[#9eacb9]">All three corrupted signals are identified. The cube opens to reveal the verified vault core.</p>
        <div className="mt-8 grid max-w-md grid-cols-3 gap-2">
          <div className="soft-panel rounded-xl p-4"><div className="mono text-[8px] tracking-[.13em] text-[#78899c]">CASES</div><div className="evidence-number mt-2 text-xl text-[#84c6a6]" data-testid="text-victory-count">{String(completedCount).padStart(2, '0')} / {String(LEVELS.length).padStart(2, '0')}</div></div>
          <div className="soft-panel rounded-xl p-4"><div className="mono text-[8px] tracking-[.13em] text-[#78899c]">TOTAL / 300</div><div className="evidence-number mt-2 text-xl text-[#e3c77c]" data-testid="text-victory-score">{totalScore}</div></div>
          <div className="soft-panel rounded-xl p-4"><div className="mono text-[8px] tracking-[.13em] text-[#78899c]">FINAL RANK</div><div className="display mt-1 text-2xl font-semibold text-[#e3c77c]" data-testid="text-victory-rank">{campaignRank}</div></div>
        </div>
        <p className="mt-3 text-[10px] leading-5 text-[#75869a]">Campaign rank: S for three flawless S cases; A for 225+ points; B below 225.</p>
        <div className="mt-8 flex max-w-md flex-col gap-2 sm:flex-row">
          <button onClick={onPlayAgain} className="gold-button flex h-12 flex-1 items-center justify-center gap-2 rounded-md text-[10px] font-bold tracking-[.12em]" data-testid="button-play-again"><RotateCcw size={14} /> PLAY AGAIN</button>
          <button onClick={onMenu} className="quiet-button flex h-12 flex-1 items-center justify-center gap-2 rounded-md border border-white/10 text-[10px] font-semibold tracking-[.12em] text-[#aebbc6]" data-testid="button-return-title"><ArrowLeft size={14} /> CASE FILES</button>
        </div>
      </div>
    </div>
  );
}

function Router() {
  return (
    <ErrorBoundary>
      <Switch>
        <Route path="/" component={App} />
        <Route component={NotFound} />
      </Switch>
    </ErrorBoundary>
  );
}

export default function RootApp() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

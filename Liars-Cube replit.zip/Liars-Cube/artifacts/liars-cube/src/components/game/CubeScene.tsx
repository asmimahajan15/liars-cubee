import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import type { CellView, CellStatus, LevelId } from '@/game/puzzles';

type CubeSceneProps = {
  cells: CellView[];
  selectedId: string | null;
  reveals: Readonly<Record<string, CellStatus>>;
  onSelect: (id: string) => void;
  onRotate: () => void;
  opened?: boolean;
  celebrate?: boolean;
  stage?: LevelId;
};

function makeLabelTexture(value: string, color: string) {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const context = canvas.getContext('2d');
  if (!context) return null;
  context.clearRect(0, 0, 128, 128);
  context.fillStyle = color;
  context.font = '600 54px "DM Mono", monospace';
  context.textAlign = 'center';
  context.textBaseline = 'middle';
  context.shadowColor = color;
  context.shadowBlur = 12;
  context.fillText(value, 64, 65);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function drawLabel(label: THREE.Sprite, cell: CellView) {
  const material = label.material as THREE.SpriteMaterial;
  const texture = material.map as THREE.CanvasTexture | null;
  const canvas = texture?.image as HTMLCanvasElement | undefined;
  const context = canvas?.getContext('2d');
  if (!texture || !canvas || !context) return;
  context.clearRect(0, 0, canvas.width, canvas.height);
  let text = '';
  let color = '#edcd82';
  if (cell.kind === 'clue') text = String(cell.clue ?? '');
  else if (cell.kind === 'mine') {
    text = 'M';
    color = '#e28b82';
  } else if (cell.kind === 'safe') {
    text = 'S';
    color = '#8dd0af';
  }
  if (text) {
    context.fillStyle = color;
    context.font = '600 54px "DM Mono", monospace';
    context.textAlign = 'center';
    context.textBaseline = 'middle';
    context.shadowColor = color;
    context.shadowBlur = 12;
    context.fillText(text, 64, 65);
  }
  texture.needsUpdate = true;
  label.visible = text.length > 0;
}

export function CubeScene({ cells, selectedId, reveals, onSelect, onRotate, opened = false, celebrate = false, stage = 1 }: CubeSceneProps) {
  const hostRef = useRef<HTMLDivElement>(null);
  const [webglUnavailable, setWebglUnavailable] = useState(false);
  const callbacksRef = useRef({ onSelect, onRotate, selectedId, opened, celebrate });
  callbacksRef.current = { onSelect, onRotate, selectedId, opened, celebrate };
  const cellRef = useRef(cells);
  cellRef.current = cells;
  const revealRef = useRef(reveals);
  revealRef.current = reveals;
  const sceneRef = useRef<THREE.Scene | null>(null);
  const materialMapRef = useRef(new Map<string, THREE.MeshStandardMaterial>());
  const meshMapRef = useRef(new Map<string, THREE.Mesh>());
  const labelMapRef = useRef(new Map<string, THREE.Sprite>());
  const edgeMapRef = useRef(new Map<string, THREE.LineSegments>());
  const hoveredIdRef = useRef<string | null>(null);
  const reducedMotionRef = useRef(false);

  useEffect(() => {
    reducedMotionRef.current = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const host = hostRef.current;
    if (!host) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    } catch {
      host.dataset.webgl = 'unavailable';
      setWebglUnavailable(true);
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.domElement.className = 'cube-canvas';
    renderer.domElement.dataset.testid = 'canvas-vault-cube';
    renderer.domElement.setAttribute('aria-label', 'Interactive 3D vault cube. Drag to rotate, then select a numbered clue.');
    renderer.domElement.setAttribute('role', 'application');
    renderer.domElement.tabIndex = 0;
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    sceneRef.current = scene;
    const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
    camera.position.set(6.9, 5.9, 8.6);
    camera.lookAt(0, 0, 0);
    const keyTint = stage === 2 ? 0x8dd0bd : stage === 3 ? 0xb8a0e5 : 0xffd997;
    const fillTint = stage === 2 ? 0x5ba999 : stage === 3 ? 0x7864ba : 0x5b9ba2;
    scene.add(new THREE.HemisphereLight(stage === 2 ? 0x9dc9c1 : stage === 3 ? 0xb2a4d8 : 0x8fa6c5, 0x101927, 2.0));
    const keyLight = new THREE.DirectionalLight(keyTint, 3.4);
    keyLight.position.set(5, 8, 7);
    scene.add(keyLight);
    const fillLight = new THREE.PointLight(fillTint, 28, 20);
    fillLight.position.set(-5, 2, -4);
    scene.add(fillLight);
    const rig = new THREE.Group();
    scene.add(rig);

    const floorGrid = new THREE.GridHelper(12, 24, stage === 2 ? 0x477b70 : stage === 3 ? 0x62558b : 0x38506a, 0x223449);
    floorGrid.position.y = -2.55;
    const gridMaterials = Array.isArray(floorGrid.material) ? floorGrid.material : [floorGrid.material];
    gridMaterials.forEach((m) => {
      const material = m as THREE.Material & { opacity?: number; transparent?: boolean };
      material.opacity = 0.2;
      material.transparent = true;
    });
    scene.add(floorGrid);

    const particles = new THREE.Group();
    for (let i = 0; i < 45; i += 1) {
      const dot = new THREE.Mesh(
        new THREE.SphereGeometry(0.012 + (i % 3) * 0.004, 6, 6),
        new THREE.MeshBasicMaterial({ color: i % 4 === 0 ? 0xd6b86f : 0x91a9c1, transparent: true, opacity: 0.35 }),
      );
      const angle = (i / 45) * Math.PI * 2;
      dot.position.set(Math.cos(angle) * (3.6 + (i % 5) * 0.34), ((i * 17) % 43) / 10 - 2.1, Math.sin(angle) * (3.2 + (i % 7) * 0.22));
      dot.userData.origin = dot.position.clone();
      dot.userData.direction = dot.position.clone().normalize();
      particles.add(dot);
    }
    scene.add(particles);

    const geometry = new RoundedBoxGeometry(0.94, 0.94, 0.94, 2, 0.045);
    const edgeGeometry = new THREE.EdgesGeometry(geometry);
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    const interactive = new THREE.Group();
    rig.add(interactive);

    const makeCellMaterial = (cell: CellView) => {
      const status = revealRef.current[cell.id] ?? (cell.kind === 'mine' || cell.kind === 'safe' ? cell.kind : undefined);
      const isClue = cell.kind === 'clue';
      const color = status === 'mine' ? 0x39313a : status === 'safe' ? 0x203c3c : isClue ? 0x26384c : 0x202d3e;
      const mat = new THREE.MeshStandardMaterial({
        color, roughness: 0.38, metalness: 0.5,
        emissive: status === 'mine' ? 0x3c1920 : status === 'safe' ? 0x174238 : isClue ? 0x152a3e : 0x111e2d,
        emissiveIntensity: 0.55,
      });
      return mat;
    };

    const currentCells = cellRef.current;
    currentCells.forEach((cell) => {
      const mesh = new THREE.Mesh(geometry, makeCellMaterial(cell));
      mesh.position.set((cell.x - 1) * 1.08, (cell.y - 1) * 1.08, (cell.z - 1) * 1.08);
      mesh.userData.origin = mesh.position.clone();
      mesh.userData.cellId = cell.id;
      interactive.add(mesh);
      meshMapRef.current.set(cell.id, mesh);
      materialMapRef.current.set(cell.id, mesh.material as THREE.MeshStandardMaterial);
      const edge = new THREE.LineSegments(edgeGeometry, new THREE.LineBasicMaterial({ color: cell.kind === 'clue' ? 0x7691a9 : 0x44586e, transparent: true, opacity: 0.57 }));
      mesh.add(edge);
      edgeMapRef.current.set(cell.id, edge);
      const labelColor = cell.kind === 'mine' ? '#e28b82' : cell.kind === 'safe' ? '#8dd0af' : '#edcd82';
      const texture = makeLabelTexture(cell.kind === 'clue' ? String(cell.clue ?? '') : '', labelColor);
      if (texture) {
        const label = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: true }));
        label.scale.set(0.56, 0.56, 1);
        label.position.copy(mesh.position);
        label.position.z += 0.5;
        label.userData.cellId = cell.id;
        label.visible = cell.kind === 'clue';
        interactive.add(label);
        labelMapRef.current.set(cell.id, label);
      }
    });

    let dragging = false;
    let didDrag = false;
    let startX = 0;
    let startY = 0;
    let lastX = 0;
    let lastY = 0;
    let velocityX = 0;
    let velocityY = 0;
    let lastInteractionTime = performance.now();
    const pointerDown = (event: PointerEvent) => {
      dragging = true;
      didDrag = false;
      hoveredIdRef.current = null;
      lastInteractionTime = performance.now();
      startX = lastX = event.clientX;
      startY = lastY = event.clientY;
      renderer.domElement.setPointerCapture(event.pointerId);
    };
    const pointerMove = (event: PointerEvent) => {
      if (!dragging) {
        const rect = renderer.domElement.getBoundingClientRect();
        pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(pointer, camera);
        const hit = raycaster.intersectObjects(interactive.children, true).find((item) => item.object.userData.cellId);
        const hitId = hit?.object.userData.cellId as string | undefined;
        const nextHover = cellRef.current.some((cell) => cell.id === hitId && cell.kind === 'clue') ? hitId ?? null : null;
        const previousHover = hoveredIdRef.current;
        if (previousHover !== nextHover) {
          if (previousHover && previousHover !== callbacksRef.current.selectedId) {
            const edge = edgeMapRef.current.get(previousHover);
            if (edge) (edge.material as THREE.LineBasicMaterial).color.setHex(0x7691a9);
          }
          hoveredIdRef.current = nextHover;
          if (nextHover) {
            const edge = edgeMapRef.current.get(nextHover);
            if (edge) (edge.material as THREE.LineBasicMaterial).color.setHex(0xd8b55e);
          }
        }
        renderer.domElement.style.cursor = nextHover ? 'pointer' : 'grab';
        return;
      }
      const dx = event.clientX - lastX;
      const dy = event.clientY - lastY;
      if (Math.hypot(event.clientX - startX, event.clientY - startY) > 6) didDrag = true;
      rig.rotation.y += dx * 0.008;
      rig.rotation.x = THREE.MathUtils.clamp(rig.rotation.x + dy * 0.008, -1.4, 1.4);
      velocityX = dx * 0.0007;
      velocityY = dy * 0.0007;
      lastX = event.clientX;
      lastY = event.clientY;
      lastInteractionTime = performance.now();
    };
    const pointerUp = (event: PointerEvent) => {
      if (!dragging) return;
      dragging = false;
      if (!didDrag) {
        const rect = renderer.domElement.getBoundingClientRect();
        pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(pointer, camera);
        const hit = raycaster.intersectObjects(interactive.children, true).find((item) => item.object.userData.cellId);
        const id = hit?.object.userData.cellId as string | undefined;
        const cell = cellRef.current.find((candidate) => candidate.id === id);
        if (cell?.kind === 'clue') callbacksRef.current.onSelect(cell.id);
      } else {
        callbacksRef.current.onRotate();
      }
      lastInteractionTime = performance.now();
    };
    const keyDown = (event: KeyboardEvent) => {
      lastInteractionTime = performance.now();
      const step = 0.14;
      if (event.key === 'ArrowLeft') rig.rotation.y -= step;
      else if (event.key === 'ArrowRight') rig.rotation.y += step;
      else if (event.key === 'ArrowUp') rig.rotation.x = THREE.MathUtils.clamp(rig.rotation.x - step, -1.4, 1.4);
      else if (event.key === 'ArrowDown') rig.rotation.x = THREE.MathUtils.clamp(rig.rotation.x + step, -1.4, 1.4);
      else if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        const clues = cellRef.current.filter((cell) => cell.kind === 'clue');
        const current = clues.find((cell) => cell.id === callbacksRef.current.selectedId);
        const next = current ? clues[(clues.indexOf(current) + 1) % clues.length] : clues[0];
        if (next) callbacksRef.current.onSelect(next.id);
      }
    };
    renderer.domElement.addEventListener('pointerdown', pointerDown);
    renderer.domElement.addEventListener('pointermove', pointerMove);
    renderer.domElement.addEventListener('pointerup', pointerUp);
    renderer.domElement.addEventListener('pointercancel', pointerUp);
    renderer.domElement.addEventListener('keydown', keyDown);

    const resizeObserver = new ResizeObserver(() => {
      const width = host.clientWidth || 1;
      const height = host.clientHeight || 1;
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    });
    resizeObserver.observe(host);
    let frame = 0;
    let lastTime = 0;
    let openedAt: number | null = null;
    let celebrationAt: number | null = null;
    const animate = (time: number) => {
      frame = requestAnimationFrame(animate);
      const delta = Math.min((time - lastTime) / 1000, 0.05);
      lastTime = time;
      if (!dragging && !reducedMotionRef.current && time - lastInteractionTime > 2200) {
        rig.rotation.y += delta * 0.12 + velocityX;
        rig.rotation.x += velocityY;
        velocityX *= 0.94;
        velocityY *= 0.94;
        particles.rotation.y += delta * 0.012;
      }
      let openProgress = 0;
      if (callbacksRef.current.opened) {
        if (openedAt === null) openedAt = time;
        openProgress = reducedMotionRef.current
          ? 1
          : THREE.MathUtils.clamp((time - openedAt) / 1050, 0, 1);
      } else {
        openedAt = null;
      }
      const easedOpen = openProgress * openProgress * (3 - 2 * openProgress);
      if (callbacksRef.current.celebrate) {
        if (celebrationAt === null) celebrationAt = time;
        const progress = reducedMotionRef.current
          ? 1
          : THREE.MathUtils.clamp((time - celebrationAt) / 850, 0, 1);
        particles.children.forEach((object) => {
          const dot = object as THREE.Mesh;
          const origin = dot.userData.origin as THREE.Vector3;
          const direction = dot.userData.direction as THREE.Vector3;
          dot.position.copy(origin).addScaledVector(direction, progress * 1.7);
          (dot.material as THREE.MeshBasicMaterial).opacity = 0.48 * (1 - progress);
        });
      } else {
        celebrationAt = null;
        particles.children.forEach((object) => {
          const dot = object as THREE.Mesh;
          dot.position.copy(dot.userData.origin as THREE.Vector3);
          (dot.material as THREE.MeshBasicMaterial).opacity = 0.35;
        });
      }
      meshMapRef.current.forEach((mesh, cellId) => {
        const origin = mesh.userData.origin as THREE.Vector3;
        const direction = origin.clone();
        if (direction.lengthSq() < 0.001) direction.set(0, 1, 0);
        direction.normalize();
        mesh.position.copy(origin).addScaledVector(direction, easedOpen * 0.72);
        const label = labelMapRef.current.get(cellId);
        if (label) label.position.set(mesh.position.x, mesh.position.y, mesh.position.z + 0.5);
      });
      renderer.render(scene, camera);
    };
    frame = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(frame);
      resizeObserver.disconnect();
      renderer.domElement.removeEventListener('pointerdown', pointerDown);
      renderer.domElement.removeEventListener('pointermove', pointerMove);
      renderer.domElement.removeEventListener('pointerup', pointerUp);
      renderer.domElement.removeEventListener('pointercancel', pointerUp);
      renderer.domElement.removeEventListener('keydown', keyDown);
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh || object instanceof THREE.LineSegments) object.geometry.dispose();
        if (object instanceof THREE.Mesh || object instanceof THREE.LineSegments || object instanceof THREE.Sprite) {
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((material) => {
            const map = (material as THREE.SpriteMaterial).map;
            map?.dispose();
            material.dispose();
          });
        }
      });
      geometry.dispose();
      edgeGeometry.dispose();
      materialMapRef.current.clear();
      meshMapRef.current.clear();
      labelMapRef.current.clear();
      edgeMapRef.current.clear();
      hoveredIdRef.current = null;
      renderer.dispose();
      renderer.domElement.remove();
      sceneRef.current = null;
    };
  }, []);

  useEffect(() => {
    materialMapRef.current.forEach((material, id) => {
      const cell = cells.find((item) => item.id === id);
      if (!cell) return;
      const status = reveals[id] ?? (cell.kind === 'mine' || cell.kind === 'safe' ? cell.kind : undefined);
      const selected = id === selectedId;
      const highlighted = selected || id === hoveredIdRef.current;
      const mesh = meshMapRef.current.get(id);
      material.color.setHex(status === 'mine' ? 0x57353a : status === 'safe' ? 0x28564b : cell.kind === 'clue' ? 0x2b4358 : 0x202d3e);
      material.emissive.setHex(status === 'mine' ? 0x562129 : status === 'safe' ? 0x1b5945 : highlighted ? 0x735a27 : cell.kind === 'clue' ? 0x213c51 : 0x111e2d);
      material.emissiveIntensity = selected ? 1.35 : highlighted ? 0.95 : 0.5;
      if (mesh) mesh.scale.setScalar(selected ? 1.045 : 1);
      const edge = edgeMapRef.current.get(id);
      if (edge) {
        const edgeMaterial = edge.material as THREE.LineBasicMaterial;
        edgeMaterial.color.setHex(highlighted ? 0xd8b55e : cell.kind === 'clue' ? 0x7691a9 : 0x44586e);
        edgeMaterial.opacity = highlighted ? 0.95 : 0.57;
      }
    });
    labelMapRef.current.forEach((label, id) => {
      const selected = id === selectedId;
      const cell = cells.find((item) => item.id === id);
      if (cell) drawLabel(label, cell);
      label.scale.setScalar(selected ? 0.68 : 0.56);
      (label.material as THREE.SpriteMaterial).opacity = selected ? 1 : 0.9;
    });
  }, [cells, reveals, selectedId]);

  return (
    <div className="cube-wrap" data-testid="scene-cube">
      <div ref={hostRef} className="cube-canvas" />
      {webglUnavailable && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 rounded-2xl border border-white/10 bg-[#101827]/90 px-8 text-center">
          <span className="eyebrow text-[10px] text-[#d8b96d]">Graphics unavailable</span>
          <p className="max-w-xs text-sm leading-6 text-[#aab6c4]">This browser could not start WebGL. Try enabling hardware acceleration or opening the investigation in a supported browser.</p>
        </div>
      )}
      <div className="cube-hint" aria-hidden="true">DRAG TO ROTATE <span className="mx-2 text-[#d1a755]">/</span> CLICK A CLUE</div>
    </div>
  );
}

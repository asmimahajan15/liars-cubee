# Liar's Cube

A browser-playable 3D deduction game where players find the one altered clue in each of three verified puzzles.

## Run & Operate

- Use the Replit **Run** button to start the Liar's Cube web preview.
- `pnpm --filter @workspace/liars-cube run dev` — run the web artifact in its configured workflow
- `pnpm --filter @workspace/liars-cube run typecheck` — typecheck the game
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- The game is client-side only; it does not require a database, login, or API.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- React + Vite + TypeScript
- Three.js for the interactive 3×3×3 cube
- Web Audio API for procedural sound
- Build: Vite

## Where things live

- `artifacts/liars-cube/src/App.tsx` — menu, level flow, scoring, save state, and game interface
- `artifacts/liars-cube/src/game/puzzles.ts` — fixed puzzle layouts, clue generation, evidence rules, and startup validation
- `artifacts/liars-cube/src/components/game/CubeScene.tsx` — Three.js cube, labels, rotation, and effects
- `artifacts/liars-cube/src/index.css` — visual theme and motion
- `artifacts/liars-cube/README.md` — game rules, controls, scoring, and run instructions
- `artifacts/liars-cube/AI_LOG.md` — prompts, tools, design decisions, and the corrected requirements mismatch

## Architecture decisions

- Puzzle layouts are fixed and checked when the puzzle module loads; the game has no random or guessed answers.
- A clue's allowed range is derived from verified neighboring statuses; one clue per level must be uniquely outside that range.
- Browser storage keeps unlocked levels and best scores so campaign progress survives refresh.

## Product

Players rotate a cube, inspect clues and verified cell statuses, use limited scans and progressive hints, and complete three levels with deterministic scoring and ranks.

## User preferences

- Keep this game procedural and self-contained; do not add external assets, APIs, or a backend unless requested.

## Gotchas

- The Vite artifact relies on its managed workflow to provide `PORT` and `BASE_PATH`; use the Replit Run button for the normal preview.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
